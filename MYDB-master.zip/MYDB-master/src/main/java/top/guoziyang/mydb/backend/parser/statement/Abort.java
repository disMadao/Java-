package top.guoziyang.mydb.backend.parser.statement;

public class Abort {
    
}
