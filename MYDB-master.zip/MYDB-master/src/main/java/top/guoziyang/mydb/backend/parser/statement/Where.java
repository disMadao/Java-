package top.guoziyang.mydb.backend.parser.statement;

public class Where {
    public SingleExpression singleExp1;
    public String logicOp;
    public SingleExpression singleExp2;
}
