package top.guoziyang.mydb.backend.parser.statement;

public class Begin {
    public boolean isRepeatableRead;
}
