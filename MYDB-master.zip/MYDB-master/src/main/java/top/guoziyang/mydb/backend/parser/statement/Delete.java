package top.guoziyang.mydb.backend.parser.statement;

public class Delete {
    public String tableName;
    public Where where;
}
