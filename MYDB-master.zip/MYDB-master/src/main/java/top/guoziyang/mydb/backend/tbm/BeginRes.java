package top.guoziyang.mydb.backend.tbm;

public class BeginRes {
    public long xid;
    public byte[] result;
}
