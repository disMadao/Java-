package top.guoziyang.mydb.backend.parser.statement;

public class Drop {
    public String tableName;
}
