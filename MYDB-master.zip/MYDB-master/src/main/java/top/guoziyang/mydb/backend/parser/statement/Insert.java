package top.guoziyang.mydb.backend.parser.statement;

public class Insert {
    public String tableName;
    public String[] values;
}
