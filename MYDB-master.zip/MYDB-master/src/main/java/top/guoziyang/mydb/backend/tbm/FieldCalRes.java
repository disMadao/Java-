package top.guoziyang.mydb.backend.tbm;

public class FieldCalRes {
    public long left;
    public long right;
}
